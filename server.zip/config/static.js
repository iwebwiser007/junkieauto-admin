"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const staticConfig = {
    enabled: true,
    dotFiles: 'ignore',
    etag: true,
    lastModified: true,
    maxAge: 0,
    immutable: false,
};
exports.default = staticConfig;
//# sourceMappingURL=static.js.map